Thank you for filing a bug against the Paper theme, however please try and provide the following information while doing so:

- the GNOME/GTK version that is on your system
- which Linux distribution you are running
- the version of Paper you are using

Most importantly: please attach a screenshot of your issue, a visual bug needs to be seen
Pick one, then copy and overwrite them to `<arc icons folder>/places/`

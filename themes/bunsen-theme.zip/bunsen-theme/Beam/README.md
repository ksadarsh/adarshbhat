SoftWaves

by hhh (hsumen@bunsenlabs.org)

A gtk theme based on Greybird, designed to be compatible 
with libgtk-3.0 (3.22.*)

Made for BunsenLabs Linux Helium. Includes an Openbox theme
and themes for Xfce4-notifyd in both stretch and jessie.

Designed to be compatible with Debian stretch. Colors 
derived from softWaves, the default wallpaper theme of stretch.

Only tested on stretch with a limited number of applications.

https://github.com/shimmerproject/Greybird
https://wiki.debian.org/DebianArt/Themes/softWaves
https://packages.debian.org/stretch/desktop-base (Debian release of softwaves)
https://www.bunsenlabs.org/
#!/bin/sh
dpkg-query -f '${binary:Package}\n' -W | wc -l

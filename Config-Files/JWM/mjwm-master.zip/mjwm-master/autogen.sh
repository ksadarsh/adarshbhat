#! /bin/sh

autoreconf -i

sleep 20s
killall conky
cd "/home/adarsh/.conky/MX-TeejeeTech"
conky -c "/home/adarsh/.conky/MX-TeejeeTech/Process Panel" &
